# TriLink firmware 0.16.0

Original verified build: `20261012-173202-b0407e2b`, ESP-IDF 5.5.5. These are the same three images flashed individually to the three tested S3 boards on 2026-10-14.

| Offset | File | Bytes |
| --- | --- | ---: |
| `0x0` | bootloader.bin | 20944 |
| `0x8000` | partition-table.bin | 3072 |
| `0x10000` | esp32s3_wakenic_p2p.bin | 898736 |

Target: ESP32-S3, 16 MiB Flash DIO/80 MHz, 8 MiB octal PSRAM. Secure Boot and Flash Encryption were disabled on the tested boards. Existing partition table: NVS0x9000/0x6000, PHY0xF000/0x1000, factory0x10000/0x100000; no OTA slots. Do not migrate another layout without a separate plan.

## Programming

Inspect the actual chip/Flash/security state and back up the affected regions before writing. Use the CH343/CH340 programming port for this workflow. Replace `<CH_PORT>` with the verified port. From the extracted package directory, with the tested esptool 4.12.0 environment:

```powershell
python -m esptool --chip esp32s3 --port '<CH_PORT>' --baud 460800 `
  --before default_reset --after no_reset `
  write_flash --flash_mode dio --flash_freq 80m --flash_size 16MB `
  0x0 bootloader.bin 0x8000 partition-table.bin 0x10000 esp32s3_wakenic_p2p.bin

python -m esptool --chip esp32s3 --port '<CH_PORT>' --baud 460800 `
  --before default_reset --after hard_reset `
  verify_flash --flash_mode dio --flash_freq 80m --flash_size 16MB `
  0x0 bootloader.bin 0x8000 partition-table.bin 0x10000 esp32s3_wakenic_p2p.bin
```

Only the three image ranges are programmed. No NVS/PHY image, device credentials, full erase, eFuse operation or force option is part of this package. Running firmware can update SDK calibration/NVS data. A source BIN hash and esptool's adjusted Flash-header/digest verification are different checks.

After startup, use the native USB port for CDC. If native USB still exposes ROM Serial/JTAG PID1001, release BOOT and briefly press RESET/EN. Application USB VID/PID is303A:4011.

## Status

Three individual boards passed programming, independent verification, startup and CDC read-only checks. **NCM currently fails with Code10 on the tested Windows host; use CDC.** NCM/DHCP/web, multi-board Room/RGB and loaded runtime acceptance are not established by these checks. Text/files/HID wake/MSC/OTA are not implemented.

`source-manifest.csv` is the original build's relative input/hash inventory, not a statement that later public build-tool adapters are byte-identical. `dependencies.lock` pins the original managed components. `validation-summary.json` is the public derived evidence. Preserve `THIRD_PARTY_NOTICES.md` and `licenses/` when distributing these images.
